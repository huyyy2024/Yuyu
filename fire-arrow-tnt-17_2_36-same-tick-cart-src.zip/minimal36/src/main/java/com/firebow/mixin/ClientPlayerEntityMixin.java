package com.firebow.mixin;

import com.firebow.event.FireBowRuntime;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    /**
     * Áp góc silent TRƯỚC khi travel tính velocity (tickMovement HEAD), để movement của tick này
     * và movement packet cùng dùng một yaw. Trước đây áp ở sendMovementPackets HEAD, sau travel.
     */
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void firebow$beforeSync(CallbackInfo ci) {
        FireBowRuntime.get().beforeSync();
    }
}
